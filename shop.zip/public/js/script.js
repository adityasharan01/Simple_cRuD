// //CLIENT SIDE CODING


// window.onload=function(){
//     let showBtn =document.querySelector('.show-products');
    
//     let addForm =document.querySelector('.add-product-form');
//     let updateForm =document.querySelector('.update-product-form');
//     let deleteForm =document.querySelector('.delete-product-form');
//     showBtn.addEventListener('click',func1);
//     addForm.addEventListener('submit',func2);
    
//     deleteForm.addEventListener('submit', func4);
//     document.addEventListener('DOMContentLoaded', function () {
//         updateForm.addEventListener('submit', func3);
//     });
//     function func1() {
//         
//         fetch('http://localhost:3000/products').then((resp)=> resp.json())
//         .then((data)=>{
//             data.forEach( (value) => {
//                 let li =document.createElement('li');
//                 li.textContent= `${value.id} - ${value.name} - RS ${value.price}`;
//                 list.appendChild(li);
//             // console.log(data);
//             })
//         })
//     }
    
//     function func2(e) {
//         e.preventDefault();
//         fetch('http://localhost:3000/products',{
//             method:'POST',
//             headers:{
//                 'Content-type': 'application/json'
//             },
//             body: JSON.stringify({
//                 name: document.getElementById('add-product-name').value,
//                 price: document.getElementById('add-product-price').value
//             })
//         }).then(resp => resp.text())
//         .then(data => console.log(data));
//     }
    
//     function func3(e) {
//         e.preventDefault();
//         let id =document.getElementById('update-product-id').value;
//         fetch('http://localhost:3000/products/'+ id,{
//             method:'PUT',
//             headers:{
//                 'Content-type': 'application/json'
//             },
//             body: JSON.stringify({
//                 price: document.getElementById('update-product-price').value
//             })
//         }).then(resp => resp.text())
//         .then(data=> console.log(data));
//     }
    
//     function func4(e) {
//         e.preventDefault();
//         let id =document.getElementById('delete-product-id').value;
//         fetch('http://localhost:3000/products/'+id ,{
//             method:'DELETE'
//         }).then(resp => resp.text())
//         .then(data=> console.log(data));
//     }
    
// }

let showBtn = document.querySelector('.show-products');
let list = document.querySelector('.product-list');
let addForm = document.querySelector('.add-product-form');
let updateForm = document.querySelector('.update-product-form');
 
showBtn.addEventListener('click',function(){
    let list= document.querySelector('.product-list');
    list.innerHTML='';
    fetch('http://localhost:3000/products')
            .then((response)=>response.json())
            .then((data)=>{
                data.forEach((product) => {
                    let li = document.createElement('li');
                    li.textContent = `${product.id} - ${product.name} - $${product.price}`;
                    list.appendChild(li);
                });
            })
})


addForm.addEventListener('submit',function(e){
    e.preventDefault();
    fetch('http://localhost:3000/products',{
        method:'POST',
        headers:{
                'Content-type':'application/json'
        },
        body:JSON.stringify({
                name: document.getElementById('add-product-name').value,
                price: document.getElementById('add-product-price').value,
        })
    }).then((response)=>response.text())
        .then((data)=> console.log(data));
})
    
updateForm.addEventListener('submit',function(e){
    e.preventDefault();
    let id =document.getElementById('update-product-id').value;
    fetch('http://localhost:3000/products'+id,{
        method:'PUT',
        headers:{
            'Content-type':'application/json'
        },
        body:JSON.stringify({
            price: document.getElementById('update-product-price').value
        })
        }).then((response)=>response.text())
        .then((data)=> console.log(data));
    })

deleteForm.addEventListener('submit',function(e){
    e.preventDefault();
    let id =document.getElementById('update-product-id').value;
    fetch('http://localhost:3000/products'+id,{
        method:'DELETE',
        }).then((response)=>response.text())
        .then((data)=> console.log(data));
    })



